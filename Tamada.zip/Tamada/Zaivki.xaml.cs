﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для Zaivki.xaml
    /// </summary>
    public partial class Zaivki : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        public Zaivki()
        {
            InitializeComponent();
            DataContext = context.Requests.ToList();
            
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {
            var zaDelete = zaivka.SelectedItems.Cast<Requests>().ToList();
            if(MessageBox.Show($"Вы точно хотите удалить следующие {zaDelete.Count()} элементов?", "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    context.Requests.RemoveRange(zaDelete);
                    context.SaveChanges();
                    MessageBox.Show("Данные удалены!");

                    zaivka.ItemsSource = context.Requests.ToList();
                }
                catch
                {
                    MessageBox.Show("Ошибка!");
                }
            }
        }

      
        private void add_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.Navigate(new dobza());
        }

        private void redak_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.Navigate(new redac((sender as Button).DataContext as Requests));
           
        }
    }
}

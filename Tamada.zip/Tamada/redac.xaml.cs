﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для redac.xaml
    /// </summary>
    public partial class redac : Page
    {

        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        private Staff st = new Staff();
        private Requests req1 = new Requests();

        public redac(Requests req)
        {
            req1=req ;
            InitializeComponent();
            DataContext = req;
            
            com.ItemsSource = context.Staff.ToList();
            if (req.id_staff != 0)
            {
                com.SelectedIndex = (int)req.id_staff - 1;
            }
        }

        private void comebake_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {

            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(req1.surname)) errors.AppendLine("Укажите вашу фамилию");
            if (string.IsNullOrWhiteSpace(req1.name)) errors.AppendLine("Укажите ваше имя");
            if (dat.SelectedDate == null) errors.AppendLine("Вы не указали дату");
            if (req1.Number_of_guests <= 0 || req1.Number_of_guests > 500) errors.AppendLine("Вы указали некорректное количество гостей");
            if (string.IsNullOrWhiteSpace(req1.Address)) errors.AppendLine("Укажите адрес проведения мероприятия");
            if (Categ.SelectedIndex == -1) errors.AppendLine("Вы не указали тип мероприятия");

            if (errors.Length > 0) { MessageBox.Show(errors.ToString(), "Ошибка"); return; }

            req1 = MainWindow.context.Requests.Find(req1.ID);
            req1.id_staff = st.ID;
            req1.Cost = st.Cost;
            req1.surname = su.Text;
            req1.name = na.Text;
            req1.Date = dat.DisplayDate;
            req1.Number_of_guests = Convert.ToInt32(nnn.Text);
            req1.Type_of_event = Categ.Text;
            req1.Address = ad.Text;
            MainWindow.context.SaveChanges();
            MessageBox.Show("Изменения сохранены!");
            Navigator.frame.Navigate(new adminn());
        }

        private void com_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var item = com.SelectedItem as Staff;
            st = item;
            req1.id_staff = st.ID;
            
            req1.Cost = st.Cost;
            ct.Text = req1.Cost.ToString();
        }
    }
}

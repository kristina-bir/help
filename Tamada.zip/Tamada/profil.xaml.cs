﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для profil.xaml
    /// </summary>
    public partial class profil : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();


        private Staff h = new Staff();
        
        public profil(Staff st)
        {
            InitializeComponent();
            DataContext = st;
            h = st;
            
            cal.BlackoutDates.AddDatesInPast();
            cal.BlackoutDates.Add(new CalendarDateRange(DateTime.Today, DateTime.Today.AddDays(7)));
            var  a = context.Requests.Where(b => b.Staff.ID == st.ID).Select(c => c.Date).ToList();
            foreach(var date in a)
            {
                cal.BlackoutDates.Add(new CalendarDateRange(date));
               
            }
              
        }

        private void naz_Click(object sender, RoutedEventArgs e)
        {

            Navigator.frame.Navigate(new Sotry());
        }

        private void zapros_Click(object sender, RoutedEventArgs e)
        {
            
            Navigator.frame.Navigate(new addZai(h));
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static public Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        
        public MainWindow()
        {
            InitializeComponent();
            Navigator.frame = fr;
            Navigator.frame.Navigate(new Sotry());
            vx.Visibility = Visibility.Hidden;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            MessageBoxResult res = MessageBox.Show("Вы уверены, что хотите закрыть программму?", "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question);

            if (res != MessageBoxResult.Yes) e.Cancel = true;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
          //  try
         //   {
         //       if(!ProjectManager.DbModel.Database.Exits())
         //           thow new Exception("Не удалось подключиться к базе данных." + "\nДальнейшая работа приложения невозможна.");
         //
          //      mainFrame.Navigate(new ProductsViewPage());
          //      ProjectManager.MainFrame = mainFrame;
          //  }
         //   catch (Exception ex)
         //   {
           //     isExit = true;
           //     ProjectManager.ShowError(ex.Message);
           //     Application.Current.Shutdown();
           //
           // }
        }

        private void vxod_Click(object sender, RoutedEventArgs e)
        {
            vxod.Visibility = Visibility.Hidden;
            vx.Visibility = Visibility.Visible;
            Navigator.frame.Navigate(new Avto());
        }

        private void vx_Click(object sender, RoutedEventArgs e)
        {
            vxod.Visibility = Visibility.Visible;
            vx.Visibility = Visibility.Hidden;
            Navigator.frame.Navigate(new Sotry());
        }
    }
}

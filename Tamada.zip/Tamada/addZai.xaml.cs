﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для addZai.xaml
    /// </summary>
    public partial class addZai : Page
    {
     
        private Requests req = new Requests();
        
        public addZai(Staff st)
        {
            InitializeComponent();
            DataContext = req;

            req.id_staff = st.ID;
            req.Cost = st.Cost;
           

        }

        private void comebake_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.GoBack();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {


            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(req.surname)) errors.AppendLine("Укажите вашу фамилию");
            if (string.IsNullOrWhiteSpace(req.name)) errors.AppendLine("Укажите ваше имя");
            if (dat.SelectedDate == null) errors.AppendLine("Вы не указали дату");
            if (req.Number_of_guests <= 0 || req.Number_of_guests > 500 ) errors.AppendLine("Вы указали некорректное количество гостей");
            if (string.IsNullOrWhiteSpace(req.Address)) errors.AppendLine("Укажите адрес проведения мероприятия");
            if(Categ.SelectedIndex == -1) errors.AppendLine("Вы не указали тип мероприятия");

            if(errors.Length > 0) { MessageBox.Show(errors.ToString(), "Ошибка"); return; }
              
            req.Type_of_event = Categ.Text;
            MainWindow.context.Requests.Add(req);


            try
            {

                MainWindow.context.SaveChanges();
              MessageBox.Show("Ваша заявка принята!");
                Navigator.frame.GoBack();

            }
            catch
            {
              MessageBox.Show("Произошла ошибка");
            }
              
            
        }        
    }
}

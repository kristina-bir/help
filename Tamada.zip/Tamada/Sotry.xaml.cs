﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для Sotry.xaml
    /// </summary>
    public partial class Sotry : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        private Staff st = new Staff();
        public Sotry()
        {
            InitializeComponent();
           
            staf.ItemsSource = context.Staff.ToList();
            Poisk();
            yb.IsChecked = true;
            

        }
        bool fil = false;
        
        private void Poisk()
        {
            var st = context.Staff.ToList();
            st = st.Where(s => s.Surname.ToLower().Contains(poisk.Text.ToLower()) || s.Advertising_text.ToLower().Contains(poisk.Text.ToLower())).ToList();
            if(st.Count == 0)
            {
                empty_list.Visibility = Visibility.Visible;
            }
            else
            {
                empty_list.Visibility = Visibility.Hidden;
            }
            if (fil == true)
            {
                var v = st.OrderBy(s => s.Cost).ToList();
                st = v;
            }
            else
            {
                var y = st.OrderByDescending(s => s.Cost).ToList();
                st = y;
            }




            staf.ItemsSource = st;
        }

        private void poisk_TextChanged(object sender, TextChangedEventArgs e)
        {
            Poisk();
        }



        private void voz_Checked(object sender, RoutedEventArgs e)
        {
            fil = true;
            Poisk();
        }

        private void yb_Checked(object sender, RoutedEventArgs e)
        {
            fil = false;
            Poisk();
        }

        private void staf_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (staf.SelectedItems.Count > 0)
            {
                var item = staf.SelectedItem as Staff;
                
                if (item != null)
                {
                    st = item;
                    profil vp = new profil(st);
                    addZai c = new addZai(st);
                    NavigationService.Navigate(new profil(st));
                }
            }

        }

        

        
        
    }
}

       
    


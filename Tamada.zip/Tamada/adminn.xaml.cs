﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для adminn.xaml
    /// </summary>
    public partial class adminn : Page
    {
        public adminn()
        {
            InitializeComponent();
            frr.Navigate(new Zaivki());
        }

        private void zai_Click(object sender, RoutedEventArgs e)
        {
           frr.Navigate(new Zaivki());
        }

        private void sot_Click(object sender, RoutedEventArgs e)
        {
            frr.Navigate(new sta());
        }
    }
}

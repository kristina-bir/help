﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для dobza.xaml
    /// </summary>
    public partial class dobza : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        private Requests req = new Requests();


        private Staff st = new Staff();
        
        public dobza()
        {
            InitializeComponent();
            DataContext = req;
            com.ItemsSource = context.Staff.ToList();
        }

        private void com_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = com.SelectedItem as Staff;
            st = item;
            req.id_staff = st.ID;
            req.Cost = st.Cost;
            ct.Text = req.Cost.ToString();
            


        }
        
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(req.surname)) errors.AppendLine("Укажите вашу фамилию");
            if (string.IsNullOrWhiteSpace(req.name)) errors.AppendLine("Укажите ваше имя");
            if (dat.SelectedDate == null) errors.AppendLine("Вы не указали дату");
            if (req.Number_of_guests <= 0 || req.Number_of_guests > 500) errors.AppendLine("Вы указали некорректное количество гостей");
            //  if (string.IsNullOrWhiteSpace(req.Type_of_event)) errors.AppendLine("Выберите тип мероприятия");
            if (string.IsNullOrWhiteSpace(req.Address)) errors.AppendLine("Укажите адрес проведения мероприятия");

            
            if (errors.Length > 0) { MessageBox.Show(errors.ToString(), "Ошибка"); return; }
            
            req.Type_of_event = Categ.Text;
            MainWindow.context.Requests.Add(req);

            try
            {

                MainWindow.context.SaveChanges();
                MessageBox.Show("Ваша заявка принята!");
                Navigator.frame.Navigate(new adminn());
            }
            catch
            {
                MessageBox.Show("Произошла ошибка");
            }
            
            
          
          
        }

        private void comebake_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.GoBack();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tamada
{
    public static class Context
    {
        public static Бабикова_курсоваяEntities3 context { get; set; }
    }
}

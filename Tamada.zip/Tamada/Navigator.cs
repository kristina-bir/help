﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace Tamada
{
    class Navigator
    {
        static public Frame frame { get; set; }
        static public Frame frr { get; set; }
    }
}

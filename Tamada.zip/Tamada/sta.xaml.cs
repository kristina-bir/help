﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для sta.xaml
    /// </summary>
    public partial class sta : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        
        public sta()
        {
            InitializeComponent();
            DataContext = context.Staff.ToList();
        }

        private void add_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.Navigate(new dobstaf());
        }

        private void delete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void redak_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}

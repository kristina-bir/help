﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Tamada
{
    /// <summary>
    /// Логика взаимодействия для Avto.xaml
    /// </summary>
    public partial class Avto : Page
    {
        Бабикова_курсоваяEntities3 context = new Бабикова_курсоваяEntities3();
        public Avto()
        {
            InitializeComponent();
        }

        void AvtoInput()
        {
            try
            {
                var u = context.Admin.Where(s => s.Login == LoginTB.Text && s.Password == PasswordTB.Password).First();
                Navigator.frame.Navigate(new adminn());
                return;
            }
            catch
            {
                MessageBox.Show("Данные были введены не верно", "", MessageBoxButton.OK);
                LoginTB.Text = ""; PasswordTB.Password = "";
            }
        }

        private void vxod_Click(object sender, RoutedEventArgs e)
        {
            if (LoginTB.Text == "" || PasswordTB.Password == "")
            {
                MessageBox.Show("Вы не ввели данные", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            AvtoInput();
        }

        private void naz_Click(object sender, RoutedEventArgs e)
        {
            Navigator.frame.Navigate(new Sotry());
        }
    }
}
